student={
    "Name":"Amjad",
    "Age":22
}

def hi(n):
    print("Hi"+" ",n)



