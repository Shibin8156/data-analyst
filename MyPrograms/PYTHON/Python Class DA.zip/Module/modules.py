import module as m
# from module import hi




m.hi("Amjad")
print(m.student["Name"])


