# f=open("C:/Users/Amjad/Documents/a.txt","r")
# # print(f.read())
# print(f.readline())
# f.close()


f=open("C:/Users/Amjad/Documents/a.txt","w")
f.write("Newstring")