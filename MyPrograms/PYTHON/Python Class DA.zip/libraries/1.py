import platform
print(dir(platform))
print(platform.system())